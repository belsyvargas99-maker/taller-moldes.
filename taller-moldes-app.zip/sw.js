const C='taller-moldes-v1';
const BASE=['./','index.html','manifest.webmanifest','icon.svg','icon-192.png','icon-512.png','vendor/jspdf.umd.min.js','vendor/jszip.min.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(BASE)));self.skipWaiting();});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  const u=new URL(e.request.url);
  if(u.origin===location.origin && e.request.mode==='navigate'){
    e.respondWith(fetch(e.request).then(r=>{caches.open(C).then(c=>c.put('index.html',r.clone()));return r;}).catch(()=>caches.match('index.html')));return;}
  e.respondWith(caches.match(e.request).then(h=>h||fetch(e.request).then(r=>{
    if(r.ok&&(u.origin===location.origin||u.hostname.endsWith('gstatic.com')||u.hostname.endsWith('googleapis.com'))){const cp=r.clone();caches.open(C).then(c=>c.put(e.request,cp));}
    return r;})));
});
